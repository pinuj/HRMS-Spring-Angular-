import { AcceptLeave } from './accept-leave';

describe('AcceptLeave', () => {
  it('should create an instance', () => {
    expect(new AcceptLeave()).toBeTruthy();
  });
});
