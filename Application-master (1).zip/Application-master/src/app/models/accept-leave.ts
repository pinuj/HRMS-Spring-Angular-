export class AcceptLeave {
    AcceptLeave!:string
    
}
