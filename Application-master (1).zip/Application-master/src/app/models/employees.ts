export class Employee {
    pId!:number;
    pName!:string;
    pDescription!:string;
    teamSize!:number;
    teamLimit!:number;
    startDate!:Date;
    praposeDate!:Date;
}

