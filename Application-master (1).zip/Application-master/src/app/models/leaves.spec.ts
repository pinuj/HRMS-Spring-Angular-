import { Leaves } from './leaves';

describe('Leaves', () => {
  it('should create an instance', () => {
    expect(new Leaves()).toBeTruthy();
  });
});
