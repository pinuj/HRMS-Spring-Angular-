export class Leaves {
    userid!:number;
    leaveId!:number;
    projectName!:"";
    reason!:string;
    userName!:"";
    startDate!:Date;
    endDate!:Date;
    status!:string;
}

