export class Project {
    pId!:number;
    pName!:string;
    pDescription!:string;
    teamSize!:number;
    teamLimit!:number;
    startDate!:Date;
    proposedDate!:Date;
}
