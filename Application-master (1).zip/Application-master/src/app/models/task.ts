export class Task {
    userid!:number;
    userName!:"";
	taskId!:number;
	taskDetails!:String;
	taskStatus!:String;
	startDate!:Date;
	endDate!:Date;
	currentProjectId!:number;
    currentProjectName!:"";
	completionDate!:String;
}
