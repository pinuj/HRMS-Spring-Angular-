import { Temp } from './temp';

describe('Temp', () => {
  it('should create an instance', () => {
    expect(new Temp()).toBeTruthy();
  });
});
