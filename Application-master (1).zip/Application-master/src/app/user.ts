export class User {
    name!:string;
    userid!:any;
    emailId!:string;
    phone!:string;
    password!:string;
    cpassword!:string;
    gender!:string;
    authId!:number;
    otp!:number;  
    newProfileCheckId!:number; 
}
